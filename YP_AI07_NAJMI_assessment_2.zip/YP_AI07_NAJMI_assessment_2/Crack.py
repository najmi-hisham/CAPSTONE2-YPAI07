# %%
#1. Setup
import matplotlib.pyplot as plt
import numpy as np
import os
import tensorflow as tf
import datetime

# %%
# 1. Data Preprocessing
import keras.api._v2.keras as keras
PATH = os.getcwd()

data_dir = 'Concrete Crack Images for Classification'

# %%
# Inspect Data
image_exts = ['jpeg','jpg','bmp','png']

for image_class in os.listdir(data_dir): 
    for image in os.listdir(os.path.join(data_dir,image_class)): 
        image_path = os.path.join(data_dir,image_class,image) 
        try:
            img = cv2.imread(image_path)
            tip = imghdr.what(image_path)
            if tip not in image_exts:
                print("Image not in ext lust {}".format(image_path))
                os.remove(image_path)
        except Exception as e:
            print("Issue with image {}".format(image_path))

data = keras.utils.image_dataset_from_directory(data_dir)
data_iterator = data.as_numpy_iterator()

batch = data_iterator.next()

fig,ax = plt.subplots(ncols=4, figsize=(20,20))
for idx,img in enumerate(batch[0][:4]):
    ax[idx].imshow(img.astype(int))
    ax[idx].title.set_text(batch[1][idx])

# %%
#Split into train and validation splits
# Create training dataset for train and test
from tensorflow import keras

train_data = keras.utils.image_dataset_from_directory(
    data_dir,
    labels="inferred",
    image_size=(256, 256),
    validation_split=0.2,
    subset="training",
    seed=1337,
    shuffle=True
)

# Create validation dataset
val_data = keras.utils.image_dataset_from_directory(
    data_dir,
    labels="inferred",
    image_size=(256, 256),
    validation_split=0.2,
    subset="validation",
    seed=1337,
    shuffle=True
)

#Split further validation dataset into validation-test splits
val_batches = tf.data.experimental.cardinality(val_data)
test_dataset = val_data.take(val_batches // 5)
validation_data = val_data.skip(val_batches // 5)

#%%
AUTOTUNE = tf.data.AUTOTUNE

train_dataset = train_data.prefetch(buffer_size=AUTOTUNE)
validation_dataset = validation_data.prefetch(buffer_size=AUTOTUNE)
test_dataset = test_dataset.prefetch(buffer_size=AUTOTUNE)
# %%
# Data Augmentation

data_augmentation = tf.keras.Sequential([
  tf.keras.layers.RandomFlip('horizontal'),
  tf.keras.layers.RandomRotation(0.2),
])

for image, _ in train_dataset.take(1):
  plt.figure(figsize=(10, 10))
  first_image = image[0]
  for i in range(9):
    ax = plt.subplot(3, 3, i + 1)
    augmented_image = data_augmentation(tf.expand_dims(first_image, 0))
    plt.imshow(augmented_image[0] / 255)
    plt.axis('off')

# %%
# Data Normalization
# You can refer to this website https://keras.io/api/applications/mobilenet/#mobilenetv2-function
preprocess_input = tf.keras.applications.mobilenet_v2.preprocess_input

# %%
# 3. Model Development
# Construct Transfer Learning Pipeline
#Load pretrained model using keras.application

IMG_SIZE=(256, 256)
# Create the base model from the pre-trained model MobileNet V2
IMG_SHAPE = IMG_SIZE + (3,)
base_model = tf.keras.applications.MobileNetV2(input_shape=IMG_SHAPE,
                                               include_top=False,
                                               weights='imagenet')
#include top false means it only contain the image extraction layer

# Let's take a look at the base model architecture
base_model.summary()

# %%
# for getting image of base_model architecture (MobileNetV2)
from tensorflow.keras.utils import plot_model

plot_model(base_model, to_file='base_model.png', show_shapes=True, show_layer_names=True)

# %%
#freeze the entire feature extractor
base_model.trainable = False
base_model.summary()
#%%

# Get the list of subdirectories (each subdirectory represents a class)
# in our case is 2 [Positive,Negative]
class_names = [f.name for f in os.scandir(data_dir) if f.is_dir()]

# %%
# add our own classification layer
# create global average pooling layer

global_avg = tf.keras.layers.GlobalAveragePooling2D()

#create output layer with dense layer
output_layer = tf.keras.layers.Dense(len(class_names), activation='softmax')

#Build pipeline
#input preprocess
input = tf.keras.Input(shape=IMG_SHAPE)
x = data_augmentation(input)
x = preprocess_input(x)

# transfer learning feature extractor
x = base_model(x,training=False) # False because freezing

# Classification layer
# global average pooling -> Dropout -> Dense(output)
x = global_avg(x)
x = tf.keras.layers.Dropout(0.3)(x)
output = output_layer(x)

# BUild Model
model = tf.keras.Model(inputs = input, outputs = output)
model.summary()
#%%
# Get new architecture and get the picture
plot_model(model, to_file='full_model.png', show_shapes=True, show_layer_names=True)

# %%
#Compile
optimizer = tf.keras.optimizers.Adam(learning_rate=0.0001)
loss = tf.keras.losses.SparseCategoricalCrossentropy()
model.compile(optimizer=optimizer,loss=loss,metrics=['accuracy'])



# %%
# create callback : early stopping, tensorboard
early_stopping = tf.keras.callbacks.EarlyStopping(patience=2)
PATH = os.getcwd()
logpath = os.path.join(PATH,"tensorboard_log",
                       datetime.datetime.now().strftime("%Y%m%d-%H%M$S"))
tb=tf.keras.callbacks.TensorBoard(logpath)
#%%
#Evaluate model with test data
model.evaluate(test_dataset)
# %%
# Model Training
EPOCHS = 10
history = model.fit(
  train_dataset,
  validation_data=validation_dataset,
  epochs=EPOCHS, callbacks=[early_stopping,tb]
)

# %%
#Evaluate model using test dataset after training
model.evaluate(test_dataset)

# %%
# 4. Model deployment
image_batch,label_batch = test_dataset.as_numpy_iterator().next()
predictions = model.predict_on_batch(image_batch)

# %%
prediction_indexes = np.argmax(predictions,axis=1)
# %%
#display result classification
label_map={i:names for i,names in enumerate(class_names)}
prediction_list=[label_map[i] for i in prediction_indexes]

label_list = [label_map[i] for i in label_batch]


# %%
#plot image graph using matplotlib

plt.figure(figsize=(10,10))
for i in range(9):
  ax = plt.subplot(3,3,i+1)
  plt.imshow(image_batch[i].astype("uint8"))
  plt.title(f"Prediction:{prediction_list[i]}\n Label:{label_list[i]}")
  plt.axis("off")
  plt.grid("off")

# %%
# Confusion matrix
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
# Convert lists to NumPy arrays
y_true = np.array(label_batch)
y_pred = np.array(prediction_indexes)

# Create confusion matrix
cm = confusion_matrix(y_true, y_pred)

# Plot the confusion matrix using seaborn
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()

# %%
# save model
model.save(os.path.join('models','Model.h5'))


